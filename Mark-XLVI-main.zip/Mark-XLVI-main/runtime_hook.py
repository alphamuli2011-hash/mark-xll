# PyInstaller runtime hook — suppress all subprocess console windows
import subprocess
import sys

_orig_run = subprocess.run
_orig_popen = subprocess.Popen

_NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW

def _patched_run(*args, **kwargs):
    if sys.platform == "win32":
        kwargs.setdefault("creationflags", _NO_WINDOW)
    return _orig_run(*args, **kwargs)

def _patched_popen(*args, **kwargs):
    if sys.platform == "win32":
        kwargs.setdefault("creationflags", _NO_WINDOW)
    return _orig_popen(*args, **kwargs)

subprocess.run = _patched_run
subprocess.Popen = _patched_popen
